package com.oe.mapper;

public class MyPageMapper {

}
