package com.oe.mapper;

public class HeartBoardMapper {

}
