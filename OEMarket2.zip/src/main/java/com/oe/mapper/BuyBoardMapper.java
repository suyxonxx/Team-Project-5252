package com.oe.mapper;

public class BuyBoardMapper {

}
