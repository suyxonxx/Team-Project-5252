package com.oe.mapper;

public class MarketBoardMapper {

}
